import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class Operations implements Runnable {

	String preference;
	public Operations(String preference) {
		super();
		this.preference = preference;
	}

	ArrayList<ProductDetails> al=new ArrayList<>();
	   
   

    public void csvReaderMethod3(String filePath,String colour,String gender,String size) {
        try {
            FileReader fileReader = new FileReader(filePath);
            CSVReader csvReader = new CSVReader(fileReader);
            
            String[] line;
            while ((line = csvReader.readNext()) != null) {

            	if(line[3].equalsIgnoreCase(gender) && line[2].equalsIgnoreCase(colour) && line[4].equalsIgnoreCase(size)) {

            		ProductDetails pd= new ProductDetails(line[0], line[1], line[2], line[3], line[4], Float.parseFloat(line[5]), Float.parseFloat(line[6]), line[7]);
            			al.add(pd);
              
           	}
            	  
            }
           

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (CsvValidationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    
    public void print(String preference) {
    	if(preference.equalsIgnoreCase("rating")) {
    	Collections.sort(al, new Comparator<ProductDetails>() {

			@Override
			public int compare(ProductDetails o1, ProductDetails o2) {
				return Float.compare(o2.getRating(), o1.getRating());
			}
		});
    	}else if(preference.equalsIgnoreCase("price")) {
    		Collections.sort(al, new Comparator<ProductDetails>() {

    			@Override
    			public int compare(ProductDetails o1, ProductDetails o2) {
    				return Float.compare(o1.getPrice(), o2.getPrice());
    			}
    		});
    	}
    	for(ProductDetails s : al) {
        	System.out.println(s);
        }
    }

	@Override
	public void run() {
		print(preference);
		
	}
}
