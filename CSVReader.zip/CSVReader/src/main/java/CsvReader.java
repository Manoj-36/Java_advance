import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import com.opencsv.*;
import com.opencsv.exceptions.CsvValidationException;

public class CsvReader {

	

    public static void main(String[] args) throws FileNotFoundException {

    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter color");
    	String colour=sc.next();
    	System.out.println("enter gender");
    	String gender=sc.next();
    	System.out.println("enter size");
    	String size=sc.next();
    	System.out.println("enter sorting field price or rating ");
    	String preference=sc.next();
    	String filePath = new File("").getAbsolutePath() + File.separator + "src/main/resources/";
        File fn=new File(filePath);
         
        
        Operations op=new Operations(preference);
        Thread t1= new Thread(op);
        
        
        System.out.println("********Reading data through OpenCSV API********");
        for(File fileName:fn.listFiles()) {
        	op.csvReaderMethod3(filePath+fileName.getName(),colour,gender,size);        	
        }
        t1.start();
       

    }
}
